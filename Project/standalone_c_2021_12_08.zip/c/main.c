volatile int constant_x = 0xabcd;

#define SW  *(volatile int*)0x00100010
#define LED *(volatile int*)0x00100014

void otherfunction(int value) {
    *(volatile int*)(0x80000004) = value;
}

int main() {
    otherfunction(0xDEADBEEF);
    constant_x++;
    while(1) {
        LED = SW;
    }
}

